package mware_lib;

/**
 * @author lukas_luehr
 * just a marker interface
 */
public interface Message {

}
