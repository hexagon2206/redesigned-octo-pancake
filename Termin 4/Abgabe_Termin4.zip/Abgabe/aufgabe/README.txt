Launch commands:
---------------

java app1.Calculator1 <ns-host> <ns-port>

java app1.Client1 <ns-host> <ns-port>
