package mware_lib;

public class RefClass {
	public RefClass(String r,SpezialObjectBroker b){
		this.ref=r;
		this.broker=b;
	}
	public String ref;
	public SpezialObjectBroker broker;
}
