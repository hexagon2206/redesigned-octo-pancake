package mware_lib.exceptions;

public class NoResponseException extends Exception {

}
