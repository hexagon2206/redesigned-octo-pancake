Aus Performance Gr�nden, sollten nicht mehr als 5 Stationen auf einem Rechner Im Labor gestartet werden.
