var searchData=
[
  ['klasse',['klasse',['../structtimux_1_1package.html#a95fc0bef41718ca6be503b1a65ede4ed',1,'timux::package::klasse()'],['../timux_8hpp.html#a3835939f8d204327e497456568a53926',1,'klasse():&#160;timux.hpp']]]
];
