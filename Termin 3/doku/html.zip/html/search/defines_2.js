var searchData=
[
  ['timux_5fsotsignal',['TIMUX_SotSignal',['../timux_8hpp.html#ad32d053f7dbac6c922a73695f3a84bce',1,'timux.hpp']]],
  ['timux_5ftimesignal',['TIMUX_TimeSignal',['../timux_8hpp.html#a1b8511f6591071dfa1f718b1cc1b69e9',1,'timux.hpp']]],
  ['timux_5ftry_5ftake_5fslot',['TIMUX_TRY_TAKE_SLOT',['../timux_8hpp.html#a3ddd10cae37188220e210c8c1b4acfaa',1,'timux.hpp']]],
  ['timux_5ftrytojoin',['TIMUX_TRYTOJOIN',['../timux_8hpp.html#add5f72936fed0c9f0a8434b3f4d16be2',1,'timux.hpp']]]
];
