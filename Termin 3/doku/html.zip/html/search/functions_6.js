var searchData=
[
  ['kill',['kill',['../classllu_1_1network_1_1_connection.html#a7e620755dde598fffc96d3ee6b3326a1',1,'llu::network::Connection::kill()'],['../classllu_1_1network_1_1_managed_connection.html#a04c4198e03082243885c058d7e703e8e',1,'llu::network::ManagedConnection::kill()'],['../classllu_1_1network_1_1_udp_connection.html#a97a62c2ab3975d9716f965aacc2f28fc',1,'llu::network::UdpConnection::kill()']]]
];
