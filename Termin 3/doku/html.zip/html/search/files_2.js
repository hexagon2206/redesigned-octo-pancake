var searchData=
[
  ['docs_2ehpp',['docs.hpp',['../docs_8hpp.html',1,'']]]
];
